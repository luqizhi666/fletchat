DEFAULT_POSTGREST_CLIENT_HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json",
}

DEFAULT_POSTGREST_CLIENT_TIMEOUT = 120
